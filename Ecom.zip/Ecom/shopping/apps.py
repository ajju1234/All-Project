from django.apps import AppConfig


class ShoppingConfig(AppConfig):
    name = 'shopping'
